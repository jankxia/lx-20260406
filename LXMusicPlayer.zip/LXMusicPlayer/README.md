# LX Music Player - 安卓APP

将 https://lxmc.611.us.ci 网站封装成安卓应用

## 项目结构

```
LXMusicPlayer/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── AndroidManifest.xml
│   │       ├── java/com/lxmusicplayer/
│   │       │   └── MainActivity.java
│   │       └── res/
│   │           ├── values/
│   │           │   ├── strings.xml
│   │           │   ├── colors.xml
│   │           │   └── themes.xml
│   │           └── mipmap/
│   │               ├── ic_launcher.png (需要添加)
│   │               └── ic_launcher_round.png (需要添加)
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## 功能特性

✅ WebView 封装网站
✅ 支持 JavaScript
✅ 支持音频播放
✅ 支持返回键导航
✅ 强制竖屏模式
✅ 硬件加速
✅ 混合内容支持（HTTP/HTTPS）

## 编译要求

- Android Studio Arctic Fox 或更高版本
- JDK 8 或更高版本
- Android SDK API 24+ (Android 7.0+)
- Gradle 8.2

## 编译步骤

### 方法 1: 使用 Android Studio

1. 打开 Android Studio
2. 选择 "Open an Existing Project"
3. 选择 `LXMusicPlayer` 文件夹
4. 等待 Gradle 同步完成
5. 点击 "Build" → "Build Bundle(s) / APK(s)" → "Build APK(s)"
6. 编译完成后，APK 文件位于 `app/build/outputs/apk/debug/app-debug.apk`

### 方法 2: 使用命令行

```bash
# 进入项目目录
cd LXMusicPlayer

# 编译 Debug 版本
./gradlew assembleDebug

# 编译 Release 版本
./gradlew assembleRelease

# APK 输出位置
# Debug: app/build/outputs/apk/debug/app-debug.apk
# Release: app/build/outputs/apk/release/app-release.apk
```

## 添加应用图标

在 `app/src/main/res/mipmap/` 目录下添加以下图标：

- `ic_launcher.png` - 512x512 像素
- `ic_launcher_round.png` - 512x512 像素（圆形图标）

或者使用 Android Studio 的 Image Asset 工具：
1. 右键 `app` → `New` → `Image Asset`
2. 选择图标类型：Launcher Icons
3. 上传你的图标
4. 点击 Finish

## 修改服务器地址

如果需要修改服务器地址，编辑 `MainActivity.java`：

```java
private static final String SERVER_URL = "https://lxmc.611.us.ci";
```

## 安装 APK

### 通过 USB 安装

```bash
# 启用 USB 调试后
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 通过手机安装

1. 将 APK 文件传输到手机
2. 在手机上打开 APK 文件
3. 允许安装未知来源的应用
4. 完成安装

## 应用权限

- INTERNET - 访问网络
- ACCESS_NETWORK_STATE - 检查网络状态
- WAKE_LOCK - 保持屏幕唤醒（播放音乐时）

## 注意事项

1. **HTTPS 证书**：如果服务器使用自签名证书，需要在代码中添加证书信任逻辑
2. **网络权限**：已配置 `android:usesCleartextTraffic="true"` 支持 HTTP
3. **最低版本**：支持 Android 7.0 (API 24) 及以上
4. **签名**：Release 版本需要签名才能发布到应用商店

## 发布到应用商店

1. 生成签名密钥：
```bash
keytool -genkey -v -keystore lx-music.keystore -alias lx-music-key -keyalg RSA -keysize 2048 -validity 10000
```

2. 在 `app/build.gradle` 中配置签名：
```gradle
android {
    signingConfigs {
        release {
            storeFile file("lx-music.keystore")
            storePassword "your-store-password"
            keyAlias "lx-music-key"
            keyPassword "your-key-password"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

3. 编译 Release 版本并上传到应用商店

## 故障排除

### 编译错误

如果遇到 Gradle 同步问题：
```bash
./gradlew clean
./gradlew build --refresh-dependencies
```

### 网页无法加载

1. 检查网络连接
2. 确认服务器地址正确
3. 查看日志：`adb logcat | grep LXMusicPlayer`

### 音频无法播放

1. 检查是否授予了网络权限
2. 确认服务器支持音频流
3. 检查 WebView 设置是否正确

## 技术支持

如有问题，请检查：
- Android Studio 的 Build 输出
- Logcat 日志
- 网络连接状态

---

**版本**: 1.0
**最低系统**: Android 7.0 (API 24)
**目标系统**: Android 14 (API 34)
