# ⚡ GitHub 编译快速开始

## 🚀 5分钟快速编译

### 第一步：创建 GitHub 仓库（1分钟）

1. 访问 https://github.com/new
2. 仓库名：`LXMusicPlayer`
3. 点击 "Create repository"

### 第二步：上传代码（2分钟）

```bash
# 解压项目
unzip LXMusicPlayer.zip
cd LXMusicPlayer

# 初始化 Git
git init
git add .
git commit -m "Initial commit"

# 添加远程仓库（替换为你的地址）
git remote add origin https://github.com/你的用户名/LXMusicPlayer.git

# 推送
git branch -M main
git push -u origin main
```

### 第三步：等待编译（2-3分钟）

1. 访问你的 GitHub 仓库
2. 点击 "Actions" 标签
3. 等待编译完成（绿色勾号）

### 第四步：下载 APK（1分钟）

1. 点击最新的编译任务
2. 滚动到底部
3. 下载 `app-debug` 或 `app-release`

## 📱 安装 APK

将下载的 APK 传输到手机，打开安装即可！

## 🎯 手动触发编译

1. 访问仓库 → Actions
2. 选择 "Build Android APK"
3. 点击 "Run workflow"

## 📚 详细文档

查看 [GITHUB_BUILD.md](GITHUB_BUILD.md) 获取完整说明。

---

**就这么简单！** 🎉
