# 🚀 使用 GitHub 编译 APK

## 📋 前提条件

- GitHub 账号
- 项目代码已上传到 GitHub

## 🎯 方法一：自动编译（推荐）

### 步骤 1：创建 GitHub 仓库

1. 访问 https://github.com/new
2. 创建新仓库：
   - 仓库名：`LXMusicPlayer`
   - 设为私有或公开都可以
   - 不要初始化 README、.gitignore 等

### 步骤 2：上传项目代码

**在你的电脑上：**

```bash
# 1. 解压项目文件
unzip LXMusicPlayer.zip
cd LXMusicPlayer

# 2. 初始化 Git 仓库
git init

# 3. 添加所有文件
git add .

# 4. 提交
git commit -m "Initial commit: LX Music Player Android App"

# 5. 添加远程仓库（替换为你的仓库地址）
git remote add origin https://github.com/你的用户名/LXMusicPlayer.git

# 6. 推送到 GitHub
git branch -M main
git push -u origin main
```

### 步骤 3：触发编译

**自动触发：**
- 推送代码到 `main` 或 `master` 分支会自动触发编译
- 创建 Pull Request 也会触发编译

**手动触发：**
1. 访问你的 GitHub 仓库
2. 点击 "Actions" 标签
3. 选择 "Build Android APK" 工作流
4. 点击 "Run workflow" → "Run workflow"

### 步骤 4：下载 APK

1. 访问你的 GitHub 仓库
2. 点击 "Actions" 标签
3. 选择最新的编译任务
4. 滚动到底部，找到 "Artifacts" 部分
5. 下载：
   - `app-debug` - Debug 版本 APK
   - `app-release` - Release 版本 APK

## 🎯 方法二：发布版本

### 步骤 1：创建标签

```bash
# 创建标签
git tag -a v1.0.0 -m "Release version 1.0.0"

# 推送标签到 GitHub
git push origin v1.0.0
```

### 步骤 2：自动创建 Release

推送标签后，GitHub Actions 会：
1. 自动编译 APK
2. 创建 GitHub Release
3. 将 APK 附加到 Release 中

### 步骤 3：下载 Release

1. 访问你的 GitHub 仓库
2. 点击 "Releases" 标签
3. 找到对应的版本
4. 下载 APK 文件

## 🎯 方法三：使用 GitHub Codespaces（在线编译）

### 步骤 1：创建 Codespace

1. 访问你的 GitHub 仓库
2. 点击 "Code" → "Codespaces" → "Create codespace on main"
3. 等待环境创建完成（约 1-2 分钟）

### 步骤 2：编译 APK

在 Codespace 终端中：

```bash
# 授予执行权限
chmod +x gradlew

# 编译 Debug 版本
./gradlew assembleDebug

# 编译 Release 版本
./gradlew assembleRelease
```

### 步骤 3：下载 APK

1. 在 Codespace 中，点击左侧文件浏览器
2. 找到 `app/build/outputs/apk/debug/app-debug.apk`
3. 右键点击 → Download

## 📊 编译状态查看

### 查看编译进度

1. 访问你的 GitHub 仓库
2. 点击 "Actions" 标签
3. 查看最新的工作流运行状态

### 编译时间

- 首次编译：约 5-10 分钟（需要下载依赖）
- 后续编译：约 2-3 分钟（使用缓存）

## 🔧 自定义配置

### 修改编译配置

编辑 `.github/workflows/build.yml`：

```yaml
# 修改 JDK 版本
- name: 设置 JDK 17
  uses: actions/setup-java@v4
  with:
    java-version: '17'  # 改为 11 或其他版本
    distribution: 'temurin'

# 修改分支触发
on:
  push:
    branches: [ main, develop ]  # 添加其他分支
```

### 添加签名配置

如果要编译签名的 Release APK，需要：

1. 在 GitHub 仓库设置中添加 Secrets：
   - `KEYSTORE_FILE` - Base64 编码的 keystore 文件
   - `KEYSTORE_PASSWORD` - keystore 密码
   - `KEY_ALIAS` - 密钥别名
   - `KEY_PASSWORD` - 密钥密码

2. 修改 `build.yml` 添加签名步骤

## 📝 工作流说明

### build.yml 功能

- ✅ 自动检出代码
- ✅ 设置 Java 环境
- ✅ 缓存 Gradle 依赖（加速编译）
- ✅ 编译 Debug APK
- ✅ 编译 Release APK
- ✅ 上传 APK 到 Artifacts
- ✅ 自动创建 Release（当推送标签时）

### 触发条件

- 推送到 `main` 或 `master` 分支
- 创建 Pull Request
- 手动触发（workflow_dispatch）
- 推送标签（创建 Release）

## 🎨 添加徽章到 README

在 README.md 中添加编译状态徽章：

```markdown
![Build Status](https://github.com/你的用户名/LXMusicPlayer/actions/workflows/build.yml/badge.svg)
```

## 🐛 常见问题

### 编译失败

1. 检查 Actions 日志
2. 确认 `build.yml` 语法正确
3. 检查 Gradle 版本兼容性

### APK 无法下载

1. 确认编译成功
2. 检查 Artifacts 是否存在
3. 尝试重新下载

### 推送失败

```bash
# 检查远程仓库
git remote -v

# 重新添加远程仓库
git remote set-url origin https://github.com/你的用户名/LXMusicPlayer.git

# 重新推送
git push -u origin main
```

## 📚 相关资源

- [GitHub Actions 文档](https://docs.github.com/en/actions)
- [Android GitHub Actions 示例](https://github.com/actions/android-build)
- [GitHub Codespaces 文档](https://docs.github.com/en/codespaces)

## 🎉 完成

现在你可以：
1. ✅ 推送代码到 GitHub
2. ✅ 自动编译 APK
3. ✅ 下载编译好的 APK
4. ✅ 安装到手机测试

---

**祝你编译顺利！** 🚀
