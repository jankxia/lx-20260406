#!/bin/bash

# LXMusicPlayer 构建脚本
# 用于快速编译安卓应用

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查依赖
check_dependencies() {
    print_info "检查依赖..."

    if ! command -v java &> /dev/null; then
        print_error "Java 未安装，请先安装 JDK 8 或更高版本"
        exit 1
    fi

    if [ ! -f "gradlew" ]; then
        print_error "gradlew 文件不存在"
        exit 1
    fi

    print_success "依赖检查完成"
}

# 清理构建
clean_build() {
    print_info "清理构建文件..."
    ./gradlew clean
    print_success "清理完成"
}

# 编译 Debug 版本
build_debug() {
    print_info "编译 Debug 版本..."
    ./gradlew assembleDebug

    if [ -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
        print_success "Debug APK 编译成功！"
        print_info "APK 位置: app/build/outputs/apk/debug/app-debug.apk"
        ls -lh app/build/outputs/apk/debug/app-debug.apk
    else
        print_error "Debug APK 编译失败"
        exit 1
    fi
}

# 编译 Release 版本
build_release() {
    print_info "编译 Release 版本..."
    ./gradlew assembleRelease

    if [ -f "app/build/outputs/apk/release/app-release-unsigned.apk" ]; then
        print_success "Release APK 编译成功！"
        print_info "APK 位置: app/build/outputs/apk/release/app-release-unsigned.apk"
        ls -lh app/build/outputs/apk/release/app-release-unsigned.apk
        print_warning "注意：Release 版本需要签名才能安装"
    else
        print_error "Release APK 编译失败"
        exit 1
    fi
}

# 安装到设备
install_debug() {
    print_info "检查设备连接..."

    if ! command -v adb &> /dev/null; then
        print_error "adb 命令未找到，请确保 Android SDK 已安装"
        exit 1
    fi

    DEVICE_COUNT=$(adb devices | grep -w "device" | wc -l)

    if [ "$DEVICE_COUNT" -eq 0 ]; then
        print_error "未检测到已连接的设备"
        print_info "请确保："
        print_info "1. 设备已通过 USB 连接"
        print_info "2. 已启用 USB 调试"
        print_info "3. 已授权电脑调试"
        exit 1
    fi

    print_success "检测到 $DEVICE_COUNT 个设备"

    if [ ! -f "app/build/outputs/apk/debug/app-debug.apk" ]; then
        print_warning "Debug APK 不存在，开始编译..."
        build_debug
    fi

    print_info "安装到设备..."
    adb install -r app/build/outputs/apk/debug/app-debug.apk

    if [ $? -eq 0 ]; then
        print_success "安装成功！"
        print_info "启动应用..."
        adb shell am start -n com.lxmusicplayer/.MainActivity
    else
        print_error "安装失败"
        exit 1
    fi
}

# 显示帮助信息
show_help() {
    echo "LXMusicPlayer 构建脚本"
    echo ""
    echo "用法: ./build.sh [选项]"
    echo ""
    echo "选项:"
    echo "  clean      清理构建文件"
    echo "  debug      编译 Debug 版本"
    echo "  release    编译 Release 版本"
    echo "  install    安装到已连接的设备"
    echo "  all        清理并编译 Debug 版本"
    echo "  help       显示此帮助信息"
    echo ""
    echo "示例:"
    echo "  ./build.sh debug      # 编译 Debug 版本"
    echo "  ./build.sh install    # 编译并安装到设备"
    echo "  ./build.sh all        # 清理并重新编译"
}

# 主函数
main() {
    case "${1:-help}" in
        clean)
            check_dependencies
            clean_build
            ;;
        debug)
            check_dependencies
            build_debug
            ;;
        release)
            check_dependencies
            build_release
            ;;
        install)
            check_dependencies
            install_debug
            ;;
        all)
            check_dependencies
            clean_build
            build_debug
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            print_error "未知选项: $1"
            show_help
            exit 1
            ;;
    esac
}

# 运行主函数
main "$@"
