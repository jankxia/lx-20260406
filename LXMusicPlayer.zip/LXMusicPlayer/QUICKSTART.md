# 快速开始指南

## 🚀 5分钟快速编译

### 前提条件

1. 安装 [Android Studio](https://developer.android.com/studio)
2. 安装 JDK 8 或更高版本
3. 下载并解压 Android SDK

### 方法一：使用 Android Studio（推荐）

1. **打开项目**
   ```
   启动 Android Studio → Open → 选择 LXMusicPlayer 文件夹
   ```

2. **等待同步**
   - 首次打开会自动下载 Gradle 和依赖
   - 等待底部进度条完成（可能需要 5-10 分钟）

3. **编译 APK**
   ```
   点击菜单：Build → Build Bundle(s) / APK(s) → Build APK(s)
   ```

4. **获取 APK**
   ```
   编译完成后点击 "locate" 按钮
   或直接打开：app/build/outputs/apk/debug/app-debug.apk
   ```

### 方法二：使用命令行

```bash
# 进入项目目录
cd LXMusicPlayer

# 给 gradlew 添加执行权限（Linux/Mac）
chmod +x gradlew

# 编译 Debug 版本
./gradlew assembleDebug

# APK 位置
ls -lh app/build/outputs/apk/debug/app-debug.apk
```

## 📱 安装到手机

### 通过 USB 安装

```bash
# 1. 启用手机的开发者选项和 USB 调试
# 2. 连接手机到电脑
# 3. 安装 APK
adb install app/build/outputs/apk/debug/app-debug.apk
```

### 通过文件传输

1. 将 `app-debug.apk` 传输到手机
2. 在手机上打开 APK 文件
3. 允许安装未知来源的应用
4. 完成安装

## 🎨 添加应用图标

### 快速方法（使用 Android Studio）

1. 右键 `app` 文件夹 → `New` → `Image Asset`
2. 选择 `Launcher Icons`
3. 上传你的图标（建议 512x512 PNG）
4. 点击 `Finish`

### 在线生成图标

访问以下网站生成完整的图标集：
- https://appicon.co/
- https://makeappicon.com/

下载后解压到 `app/src/main/res/` 目录

## ⚙️ 修改配置

### 修改服务器地址

编辑 `app/src/main/java/com/lxmusicplayer/MainActivity.java`：

```java
private static final String SERVER_URL = "https://lxmc.611.us.ci";
```

### 修改应用名称

编辑 `app/src/main/res/values/strings.xml`：

```xml
<string name="app_name">你的应用名称</string>
```

### 修改版本号

编辑 `app/build.gradle`：

```gradle
defaultConfig {
    versionCode 2  // 每次发布递增
    versionName "1.1"  // 显示给用户的版本
}
```

## 🔧 常见问题

### 编译失败

```bash
# 清理并重新编译
./gradlew clean
./gradlew build --refresh-dependencies
```

### Gradle 同步失败

1. 检查网络连接
2. 修改 `gradle/wrapper/gradle-wrapper.properties` 中的镜像源
3. 或使用 Android Studio 的 "File → Invalidate Caches → Invalidate and Restart"

### APK 无法安装

1. 检查手机是否允许安装未知来源应用
2. 确认 Android 版本 ≥ 7.0
3. 尝试卸载旧版本后重新安装

### 网页无法加载

1. 检查网络连接
2. 确认服务器地址正确
3. 查看应用日志：`adb logcat | grep LXMusicPlayer`

## 📦 发布到应用商店

### 1. 生成签名密钥

```bash
keytool -genkey -v -keystore lx-music.keystore \
  -alias lx-music-key -keyalg RSA -keysize 2048 -validity 10000
```

### 2. 配置签名

编辑 `app/build.gradle`：

```gradle
android {
    signingConfigs {
        release {
            storeFile file("lx-music.keystore")
            storePassword "your-store-password"
            keyAlias "lx-music-key"
            keyPassword "your-key-password"
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
    }
}
```

### 3. 编译 Release 版本

```bash
./gradlew assembleRelease
```

### 4. 上传到应用商店

- Google Play: https://play.google.com/console
- 华为应用市场: https://developer.huawei.com/consumer/cn/
- 小米应用商店: https://dev.mi.com/distribute

## 📚 更多资源

- [Android 官方文档](https://developer.android.com/docs)
- [Gradle 用户指南](https://docs.gradle.org/current/userguide/userguide.html)
- [WebView 最佳实践](https://developer.android.com/guide/webapps/webview)

## 💡 提示

- 首次编译会下载大量依赖，请耐心等待
- 建议使用稳定的网络环境
- 可以配置 Gradle 镜像源加速下载
- Debug 版本包含调试信息，体积较大
- Release 版本经过混淆和优化，体积更小

---

**需要帮助？** 查看 [README.md](README.md) 获取详细信息
