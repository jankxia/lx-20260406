# 图标说明

## 需要添加的图标文件

在 `app/src/main/res/mipmap/` 目录下添加以下图标：

### 必需的图标

1. **ic_launcher.png** - 应用图标（方形）
   - 尺寸：512x512 像素
   - 格式：PNG（支持透明背景）
   - 用途：应用启动图标

2. **ic_launcher_round.png** - 圆形图标
   - 尺寸：512x512 像素
   - 格式：PNG（支持透明背景）
   - 用途：圆形启动图标（部分设备）

### 可选的图标（不同尺寸）

为了更好的显示效果，可以添加以下尺寸的图标：

- mdpi: 48x48
- hdpi: 72x72
- xhdpi: 96x96
- xxhdpi: 144x144
- xxxhdpi: 192x192

## 使用 Android Studio 生成图标

1. 在 Android Studio 中打开项目
2. 右键点击 `app` 文件夹
3. 选择 `New` → `Image Asset`
4. 在弹出的窗口中：
   - Icon Type: Launcher Icons (Adaptive and Legacy)
   - Foreground Layer: 上传你的图标
   - Background Layer: 选择背景颜色
5. 点击 `Next` → `Finish`

## 在线图标生成工具

推荐使用以下工具生成安卓图标：

- Android Asset Studio: https://romannurik.github.io/AndroidAssetStudio/
- AppIconGenerator: https://appicon.co/
- MakeAppIcon: https://makeappicon.com/

## 图标设计建议

1. **简洁明了** - 图标应该简单易懂
2. **高对比度** - 确保在不同背景下都清晰可见
3. **品牌一致** - 使用与网站一致的颜色和风格
4. **避免文字** - 图标中不要包含文字
5. **圆角处理** - 适当添加圆角，符合安卓设计规范

## 临时解决方案

如果暂时没有图标，可以使用以下方法：

1. 使用默认的 Android 图标（已包含在项目中）
2. 使用在线工具快速生成一个简单的图标
3. 使用网站截图作为临时图标

## 示例图标

你可以使用以下方式创建临时图标：

```bash
# 使用 ImageMagick 创建一个简单的图标（如果已安装）
convert -size 512x512 xc:purple -gravity center -pointsize 200 -fill white -annotate +0+0 "LX" ic_launcher.png
```

或者使用任何图片编辑工具创建一个 512x512 的 PNG 图片。
