# LXMusicPlayer 项目结构

```
LXMusicPlayer/
├── app/                              # 应用模块
│   ├── build.gradle                  # 应用级构建配置
│   ├── proguard-rules.pro            # ProGuard 混淆规则
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml   # 应用清单文件
│           ├── java/                 # Java 源代码
│           │   └── com/lxmusicplayer/
│           │       └── MainActivity.java  # 主活动
│           └── res/                  # 资源文件
│               ├── mipmap/           # 图标资源（需要添加）
│               │   ├── ic_launcher.png
│               │   └── ic_launcher_round.png
│               └── values/           # 值资源
│                   ├── colors.xml    # 颜色定义
│                   ├── strings.xml   # 字符串资源
│                   └── themes.xml    # 主题样式
│
├── build.gradle                      # 项目级构建配置
├── settings.gradle                   # 项目设置
├── gradle.properties                # Gradle 属性配置
├── gradlew                           # Gradle 包装脚本（Unix）
├── gradlew.bat                       # Gradle 包装脚本（Windows）
├── .gitignore                        # Git 忽略文件
│
├── README.md                         # 项目说明文档
├── QUICKSTART.md                     # 快速开始指南
├── ICONS.md                          # 图标说明
└── STRUCTURE.md                      # 本文件（项目结构说明）
```

## 核心文件说明

### MainActivity.java

主活动文件，负责：
- 初始化 WebView
- 配置 WebView 设置
- 加载网页内容
- 处理返回键导航
- 管理生命周期

**关键配置：**
```java
private static final String SERVER_URL = "https://lxmc.611.us.ci";
```

### AndroidManifest.xml

应用清单文件，定义：
- 应用包名
- 权限声明
- 组件注册
- 应用配置

**关键权限：**
- INTERNET - 网络访问
- ACCESS_NETWORK_STATE - 网络状态检查
- WAKE_LOCK - 保持唤醒

### build.gradle (app)

应用级构建配置：
- 编译 SDK 版本
- 依赖库
- 构建类型
- 签名配置

### build.gradle (project)

项目级构建配置：
- Gradle 插件版本
- 仓库配置
- 全局设置

## 资源文件说明

### values/strings.xml

字符串资源：
```xml
<string name="app_name">LX Music</string>
```

### values/colors.xml

颜色定义：
- purple_200, purple_500, purple_700
- teal_200, teal_700
- black, white

### values/themes.xml

主题样式：
- Material Design 主题
- 颜色方案
- 状态栏颜色

### mipmap/

图标资源目录：
- ic_launcher.png - 方形图标
- ic_launcher_round.png - 圆形图标

## 构建输出目录

```
app/build/
├── outputs/
│   └── apk/
│       ├── debug/
│       │   └── app-debug.apk          # Debug 版本
│       └── release/
│           └── app-release.apk        # Release 版本
├── intermediates/
└── generated/
```

## Gradle 目录

```
gradle/
└── wrapper/
    ├── gradle-wrapper.jar            # Gradle 包装器 JAR
    └── gradle-wrapper.properties     # Gradle 配置
```

## 配置文件说明

### gradle.properties

Gradle 属性：
- JVM 参数
- AndroidX 启用
- Jetifier 启用

### .gitignore

Git 忽略规则：
- 编译输出
- IDE 配置
- 密钥文件
- 临时文件

## 开发工作流

### 修改代码

1. 编辑 `MainActivity.java`
2. 点击 "Run" 或使用快捷键
3. 查看日志输出

### 修改资源

1. 编辑 `res/values/` 下的文件
2. 重新编译
3. 查看效果

### 添加依赖

编辑 `app/build.gradle`：
```gradle
dependencies {
    implementation 'com.example:library:1.0.0'
}
```

### 调试应用

```bash
# 查看日志
adb logcat | grep LXMusicPlayer

# 连接调试
adb shell am start -n com.lxmusicplayer/.MainActivity
```

## 版本控制

### 推荐的 Git 工作流

```bash
# 初始化仓库
git init

# 添加文件
git add .

# 提交
git commit -m "Initial commit"

# 推送到远程
git remote add origin <repository-url>
git push -u origin main
```

### 分支策略

- `main` - 稳定版本
- `develop` - 开发分支
- `feature/*` - 功能分支

## 性能优化建议

### WebView 优化

1. 启用硬件加速
2. 合理设置缓存策略
3. 优化 JavaScript 执行
4. 减少内存占用

### APK 优化

1. 启用代码混淆
2. 压缩资源
3. 移除未使用的代码
4. 使用 App Bundle

## 安全建议

1. 不要在代码中硬编码密钥
2. 使用 ProGuard 混淆代码
3. 验证网络请求
4. 保护用户数据

## 扩展功能

### 添加推送通知

集成 Firebase Cloud Messaging：
```gradle
implementation 'com.google.firebase:firebase-messaging:23.0.0'
```

### 添加分享功能

```java
Intent shareIntent = new Intent(Intent.ACTION_SEND);
shareIntent.setType("text/plain");
shareIntent.putExtra(Intent.EXTRA_TEXT, webView.getUrl());
startActivity(Intent.createChooser(shareIntent, "分享"));
```

### 添加下载功能

```java
DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
request.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, filename);
DownloadManager manager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
manager.enqueue(request);
```

---

**相关文档：**
- [README.md](README.md) - 项目说明
- [QUICKSTART.md](QUICKSTART.md) - 快速开始
- [ICONS.md](ICONS.md) - 图标说明
