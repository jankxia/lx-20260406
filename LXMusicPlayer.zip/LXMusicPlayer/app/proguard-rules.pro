# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Application
-keep public class * extends android.app.Service
-keep public class * extends android.content.BroadcastReceiver
-keep public class * extends android.content.ContentProvider
-keep public class * extends android.preference.Preference
-keep public class * extends android.view.View
-keep public class * extends android.webkit.WebViewClient
-keep public class * extends android.webkit.WebChromeClient
-keepclassmembers class * extends android.webkit.WebViewClient {
    *;
}
-keepclassmembers class * extends android.webkit.WebChromeClient {
    *;
}
