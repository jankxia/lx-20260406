@echo off
REM LXMusicPlayer 构建脚本 (Windows)
REM 用于快速编译安卓应用

setlocal enabledelayedexpansion

REM 颜色定义（Windows 10+）
for /F %%a in ('echo prompt $E ^| cmd') do set "ESC=%%a"
set "RED=%ESC%[31m"
set "GREEN=%ESC%[32m"
set "YELLOW=%ESC%[33m"
set "BLUE=%ESC%[34m"
set "NC=%ESC%[0m"

REM 打印带颜色的消息
:print_info
echo %BLUE%[INFO]%NC% %~1
goto :eof

:print_success
echo %GREEN%[SUCCESS]%NC% %~1
goto :eof

:print_warning
echo %YELLOW%[WARNING]%NC% %~1
goto :eof

:print_error
echo %RED%[ERROR]%NC% %~1
goto :eof

REM 检查依赖
:check_dependencies
call :print_info "检查依赖..."

where java >nul 2>&1
if %errorlevel% neq 0 (
    call :print_error "Java 未安装，请先安装 JDK 8 或更高版本"
    exit /b 1
)

if not exist "gradlew.bat" (
    call :print_error "gradlew.bat 文件不存在"
    exit /b 1
)

call :print_success "依赖检查完成"
goto :eof

REM 清理构建
:clean_build
call :print_info "清理构建文件..."
call gradlew.bat clean
if %errorlevel% neq 0 (
    call :print_error "清理失败"
    exit /b 1
)
call :print_success "清理完成"
goto :eof

REM 编译 Debug 版本
:build_debug
call :print_info "编译 Debug 版本..."
call gradlew.bat assembleDebug
if %errorlevel% neq 0 (
    call :print_error "Debug APK 编译失败"
    exit /b 1
)

if exist "app\build\outputs\apk\debug\app-debug.apk" (
    call :print_success "Debug APK 编译成功！"
    call :print_info "APK 位置: app\build\outputs\apk\debug\app-debug.apk"
    dir "app\build\outputs\apk\debug\app-debug.apk"
) else (
    call :print_error "Debug APK 编译失败"
    exit /b 1
)
goto :eof

REM 编译 Release 版本
:build_release
call :print_info "编译 Release 版本..."
call gradlew.bat assembleRelease
if %errorlevel% neq 0 (
    call :print_error "Release APK 编译失败"
    exit /b 1
)

if exist "app\build\outputs\apk\release\app-release-unsigned.apk" (
    call :print_success "Release APK 编译成功！"
    call :print_info "APK 位置: app\build\outputs\apk\release\app-release-unsigned.apk"
    dir "app\build\outputs\apk\release\app-release-unsigned.apk"
    call :print_warning "注意：Release 版本需要签名才能安装"
) else (
    call :print_error "Release APK 编译失败"
    exit /b 1
)
goto :eof

REM 安装到设备
:install_debug
call :print_info "检查设备连接..."

where adb >nul 2>&1
if %errorlevel% neq 0 (
    call :print_error "adb 命令未找到，请确保 Android SDK 已安装"
    exit /b 1
)

for /f %%i in ('adb devices ^| find /c /v "" ^| find /v "0"') do set DEVICE_COUNT=%%i
set /a DEVICE_COUNT-=1

if %DEVICE_COUNT% leq 0 (
    call :print_error "未检测到已连接的设备"
    call :print_info "请确保："
    call :print_info "1. 设备已通过 USB 连接"
    call :print_info "2. 已启用 USB 调试"
    call :print_info "3. 已授权电脑调试"
    exit /b 1
)

call :print_success "检测到 %DEVICE_COUNT% 个设备"

if not exist "app\build\outputs\apk\debug\app-debug.apk" (
    call :print_warning "Debug APK 不存在，开始编译..."
    call :build_debug
)

call :print_info "安装到设备..."
adb install -r app\build\outputs\apk\debug\app-debug.apk
if %errorlevel% neq 0 (
    call :print_error "安装失败"
    exit /b 1
)

call :print_success "安装成功！"
call :print_info "启动应用..."
adb shell am start -n com.lxmusicplayer/.MainActivity
goto :eof

REM 显示帮助信息
:show_help
echo LXMusicPlayer 构建脚本 (Windows)
echo.
echo 用法: build.bat [选项]
echo.
echo 选项:
echo   clean      清理构建文件
echo   debug      编译 Debug 版本
echo   release    编译 Release 版本
echo   install    安装到已连接的设备
echo   all        清理并编译 Debug 版本
echo   help       显示此帮助信息
echo.
echo 示例:
echo   build.bat debug      # 编译 Debug 版本
echo   build.bat install    # 编译并安装到设备
echo   build.bat all        # 清理并重新编译
goto :eof

REM 主函数
:main
if "%~1"=="" goto show_help
if "%~1"=="clean" (
    call :check_dependencies
    call :clean_build
) else if "%~1"=="debug" (
    call :check_dependencies
    call :build_debug
) else if "%~1"=="release" (
    call :check_dependencies
    call :build_release
) else if "%~1"=="install" (
    call :check_dependencies
    call :install_debug
) else if "%~1"=="all" (
    call :check_dependencies
    call :clean_build
    call :build_debug
) else if "%~1"=="help" (
    call :show_help
) else (
    call :print_error "未知选项: %~1"
    call :show_help
    exit /b 1
)

goto :eof

REM 运行主函数
call :main %*
